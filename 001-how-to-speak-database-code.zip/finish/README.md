Epic PHP!
=========

This repository holds the screencast code, script and coding activities for
episode 1 of the upcoming PHP series "Writing Epic PHP in one month".

Contributing
------------

Progress will be posted to this repository as we work. If you'd like to contribute,
either open up an issue or (even better) fork the code and create a pull
request. We want to create the best PHP tutorial for beginners, a job that's
best solved by as many people as possible :).
